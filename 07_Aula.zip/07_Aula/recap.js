//Revisão de funções
