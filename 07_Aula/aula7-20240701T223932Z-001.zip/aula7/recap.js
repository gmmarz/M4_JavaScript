function minhaSuperFuncao(parametro, parametro2) {
    let magia = parametro + parametro2
    return magia
}



console.log(minhaSuperFuncao('banana', 'uva'))
