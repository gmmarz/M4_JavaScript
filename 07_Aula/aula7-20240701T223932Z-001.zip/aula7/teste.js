
function somar(a, b) {
    console.log(a, b)
    return a + b
}

const adicao = (a , b) => {
    a , b
}


const botaoMaluco = function (a, b) {
    console.log(a, b )
}

botaoMaluco('a', 'b')