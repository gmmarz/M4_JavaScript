// Exemplo arrow function;

const minhaFunc = () => {
    return "Hello Arrow Function!"
}

console.log(minhaFunc())


// Funções anônimas:

const nomeProfissao = function (parametro1, parametro2) {
    return `Dados informados: ${parametro1}, ${parametro2}`
}

console.log(nomeProfissao('Thiago', 'professor'))